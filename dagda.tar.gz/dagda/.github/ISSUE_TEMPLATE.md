### Short description

I was trying to do [...]

### Reproduction steps

1. Start Dagda server with the parameters '...'
2. Type the Dagda CLI command '....'
3. '....'
4. '....'

### Expected results

I expected that by analyzing the docker image '...' and showing the report '...' then '...' would happen.

### Actual results

Instead of '...', what I saw was that '...' happened instead.

### On which platforms did you notice this:

Please complete the following information:

 - OS: [e.g. Ubuntu]
 - OS Version: [e.g. (~$ uname -a)]
 - Python version: [e.g. Python 3.4]
 - Docker version [e.g. 17.05.0-ce]
 - MongoDB version [e.g. 3.2]

### Backtrace

```
Please copy paste the backtrace here if available
```

### Solution

A possible solution for this issue would be '...'