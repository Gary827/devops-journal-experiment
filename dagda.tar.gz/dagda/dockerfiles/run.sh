#!/bin/sh
python dagda.py $@
